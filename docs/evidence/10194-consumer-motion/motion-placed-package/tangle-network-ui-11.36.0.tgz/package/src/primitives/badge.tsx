import { cva, type VariantProps } from "class-variance-authority";
import type * as React from "react";
import { focusRing } from "../lib/focus";
import { cn } from "../lib/utils";

const badgeVariants = cva(
  `inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 font-medium text-xs transition-colors ${focusRing}`,
  {
    variants: {
      variant: {
        default: "border-transparent bg-primary text-primary-foreground",
        secondary: "border-transparent bg-secondary text-secondary-foreground",
        destructive: "border-transparent bg-destructive/15 border-destructive/25 text-destructive",
        outline: "text-foreground border-border",
        success:
          "border-[var(--surface-success-border)] bg-[var(--surface-success-bg)] text-[var(--surface-success-text)]",
        warning:
          "border-[var(--surface-warning-border)] bg-[var(--surface-warning-bg)] text-[var(--surface-warning-text)]",
        error:
          "border-[var(--surface-danger-border)] bg-[var(--surface-danger-bg)] text-[var(--surface-danger-text)]",
        info:
          "border-[var(--surface-info-border)] bg-[var(--surface-info-bg)] text-[var(--surface-info-text)]",
        sandbox:
          "border-border bg-[var(--accent-surface-soft)] text-[var(--accent-text)]",
        /* Sandbox lifecycle variants: compatibility only, painted with the
         * status triples. A lifecycle state is domain meaning, so its mapping
         * lives in sandbox-ui's lifecycle adapter over `StatusPill`; these
         * stay until consumers move. Running is up and healthy (success);
         * creating is still in progress (info, as StatusPill's `running`);
         * stopped and warm can be resumed (warning); cold is archived (info);
         * deleted is gone (neutral). */
        running:
          "border-[var(--surface-success-border)] bg-[var(--surface-success-bg)] text-[var(--surface-success-text)]",
        creating:
          "border-[var(--surface-info-border)] bg-[var(--surface-info-bg)] text-[var(--surface-info-text)]",
        stopped:
          "border-[var(--surface-warning-border)] bg-[var(--surface-warning-bg)] text-[var(--surface-warning-text)]",
        warm:
          "border-[var(--surface-warning-border)] bg-[var(--surface-warning-bg)] text-[var(--surface-warning-text)]",
        cold:
          "border-[var(--surface-info-border)] bg-[var(--surface-info-bg)] text-[var(--surface-info-text)]",
        deleted:
          "border-[var(--surface-neutral-border)] bg-[var(--surface-neutral-bg)] text-[var(--surface-neutral-text)]",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  },
);

/**
 * `success`, `warning`, `error` and `info` paint the same triples as
 * `StatusPill`; for a status, prefer `StatusPill`, which adds the glyph that
 * survives greyscale. The lifecycle variants (`running`, `creating`,
 * `stopped`, `warm`, `cold`, `deleted`) are deprecated: use sandbox-ui's
 * lifecycle adapter.
 */
export type BadgeVariant =
  | "default"
  | "secondary"
  | "destructive"
  | "outline"
  | "success"
  | "warning"
  | "error"
  | "info"
  | "sandbox"
  | "running"
  | "creating"
  | "stopped"
  | "warm"
  | "cold"
  | "deleted"
  | null;

export interface BadgeProps extends VariantProps<typeof badgeVariants> {
  variant?: BadgeVariant;
  className?: string;
  children?: React.ReactNode;
  dot?: boolean;
  onClick?: React.MouseEventHandler<HTMLDivElement>;
  style?: React.CSSProperties;
  id?: string;
  role?: React.AriaRole;
  title?: string;
  [key: string]: unknown;
}

const statusDotClass: Record<string, string> = {
  running: "status-dot status-dot-running",
  creating: "status-dot status-dot-creating",
  stopped: "status-dot status-dot-stopped",
  warm: "status-dot status-dot-warm",
  cold: "status-dot status-dot-cold",
  error: "status-dot status-dot-error",
  deleted: "status-dot status-dot-deleted",
};

function Badge({ className, variant, dot, children, ...props }: BadgeProps) {
  const dotClass = dot && variant ? statusDotClass[variant] : null;

  return (
    <div className={cn(badgeVariants({ variant }), className)} {...props}>
      {dotClass && <span className={dotClass} aria-hidden />}
      {children}
    </div>
  );
}

export { Badge, badgeVariants };
