import { X } from "lucide-react";
import * as React from "react";
import { focusRing } from "../lib/focus";
import { cn } from "../lib/utils";
import { TONE_CLASSES, type Tone } from "./tone";

/**
 * A static label for what something IS: a category, a kind, a named value.
 *
 * Tags are squared-off (`rounded-md`) where `StatusPill` is fully round, so a
 * category and a state never share a silhouette even before colour is read.
 * For a state, use `StatusPill`. For a label the user presses, use `Chip`.
 *
 * `onRemove` adds a native remove button after the label — the removable
 * variant, for a recipient, an applied filter or an attached item. The tag
 * itself stays non-interactive, so the remove button is the only tab stop.
 * Removing a tag unmounts its focused button; move focus to the next tag or
 * the input that adds tags, or keyboard focus falls to the page.
 */
export interface TagProps extends Omit<React.HTMLAttributes<HTMLSpanElement>, "children"> {
  children: React.ReactNode;
  /** Categorical tone, or `neutral` (the default) for an uncategorised label. */
  tone?: Tone;
  /** `soft` fills the tag; `outline` keeps only the border, for dense rows. */
  emphasis?: "soft" | "outline";
  size?: "sm" | "md";
  /** A leading glyph, drawn in the tone's icon colour. Decorative. */
  icon?: React.ReactNode;
  /** Shows a remove button; called when it is pressed. */
  onRemove?: () => void;
  /**
   * Accessible name of the remove button. Defaults to "Remove <label>" when
   * the label is a string; pass it when the label is not plain text.
   */
  removeLabel?: string;
  /**
   * Wraps a long label onto more lines instead of truncating it. Use it where
   * the full text matters and no hover is available to read a `title`, such
   * as model-written part names read on a phone or on paper.
   */
  wrap?: boolean;
}

const SIZE = {
  sm: "gap-1 px-2 text-xs [&_svg]:size-3",
  md: "gap-1.5 px-2.5 text-sm [&_svg]:size-3.5",
} as const;

// A truncating tag has one fixed height. A wrapping tag carries its vertical
// padding on the label instead, sized so one line is exactly that height
// (sm: 16px line + 6 + 2px border = 24; md: 20 + 6 + 2 = 28), and aligns the
// icon and remove button to the first line rather than the middle.
const WRAP = {
  sm: { box: "items-start", label: "py-[3px]", icon: "h-[22px] items-center" },
  md: { box: "items-start", label: "py-[3px]", icon: "h-[26px] items-center" },
} as const;

const Tag = React.forwardRef<HTMLSpanElement, TagProps>(
  (
    { className, children, tone = "neutral", emphasis = "soft", size = "sm", icon, onRemove, removeLabel, wrap = false, ...props },
    ref,
  ) => {
    const classes = TONE_CLASSES[tone];
    const label = removeLabel ?? (typeof children === "string" ? `Remove ${children}` : "Remove");
    return (
      <span
        ref={ref}
        className={cn(
          "inline-flex min-w-0 max-w-full shrink-0 rounded-md border font-medium",
          SIZE[size],
          wrap ? WRAP[size].box : ["items-center", size === "sm" ? "h-6" : "h-7"],
          emphasis === "outline" ? classes.outline : classes.surface,
          onRemove && (size === "sm" ? "pr-0.5" : "pr-1"),
          className,
        )}
        {...props}
      >
        {icon ? (
          <span aria-hidden="true" className={cn("inline-flex shrink-0", wrap && WRAP[size].icon, classes.icon)}>
            {icon}
          </span>
        ) : null}
        {/* By default a long label truncates here rather than pushing the
            remove button out, and the title gives its full text on hover.
            `wrap` breaks it across lines instead, even inside one long token. */}
        {wrap ? (
          <span className={cn("min-w-0 [overflow-wrap:anywhere]", WRAP[size].label)}>{children}</span>
        ) : (
          <span className="min-w-0 truncate" title={typeof children === "string" ? children : undefined}>
            {children}
          </span>
        )}
        {onRemove ? (
          <button
            type="button"
            aria-label={label}
            onClick={onRemove}
            className={cn(
              // The visible target is the glyph's box; the pseudo-element widens
              // the hit area without moving the tag's layout.
              "relative inline-flex shrink-0 items-center justify-center rounded-sm opacity-70 transition-[opacity,background-color] duration-150 ease-out hover:bg-[color-mix(in_srgb,currentColor_14%,transparent)] hover:opacity-100 before:absolute before:-inset-1.5 before:content-['']",
              size === "sm" ? "size-5" : "size-6",
              // Centred on the first line box (22px sm, 26px md) when wrapping.
              wrap && "mt-px",
              focusRing,
            )}
          >
            <X aria-hidden="true" />
          </button>
        ) : null}
      </span>
    );
  },
);
Tag.displayName = "Tag";

export { Tag };
