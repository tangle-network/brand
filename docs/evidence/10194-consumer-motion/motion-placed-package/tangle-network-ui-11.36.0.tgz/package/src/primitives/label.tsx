"use client";

import * as LabelPrimitive from "@radix-ui/react-label";
import { labelVariants } from "../presentation";
import * as React from "react";
import { cn } from "../lib/utils";

// One label size (`--font-size-label`, 14px) for every field size.


const Label = React.forwardRef<
  React.ElementRef<typeof LabelPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof LabelPrimitive.Root>
>(({ className, ...props }, ref) => (
  <LabelPrimitive.Root
    ref={ref}
    className={cn(labelVariants(), className)}
    {...props}
  />
));
Label.displayName = LabelPrimitive.Root.displayName;

export { Label };
