import {
  Children,
  createContext,
  isValidElement,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ComponentProps,
} from "react";
import type { ExtraProps } from "react-markdown";
import { Check, Copy } from "lucide-react";
import { focusRing, focusRingInset } from "../lib/focus";
import { cn } from "../lib/utils";

type Element = NonNullable<ExtraProps["node"]>;
type ElementContent = Element["children"][number];

/** A figure: optional sign or currency, digits with separators, an optional unit. */
const NUMERIC_CELL = /^[(]?[-+−]?\s?[$€£¥₹]?\s?\d[\d,_ ]*(?:\.\d+)?\s?(?:%|[kKmMbB]|x|ms|s|h|pp)?[)]?$/;

/** The text of a hast subtree, as a reader sees it. */
function textOf(node: ElementContent | Element): string {
  if (node.type === "text") return node.value;
  if (node.type !== "element") return "";
  return node.children.map(textOf).join("");
}

function rowsOf(table: Element): { header: string[][]; body: string[][] } {
  const header: string[][] = [];
  const body: string[][] = [];
  const visit = (element: Element, inHead: boolean) => {
    for (const child of element.children) {
      if (child.type !== "element") continue;
      if (child.tagName === "tr") {
        const cells = child.children
          .filter((cell): cell is Element => cell.type === "element" && (cell.tagName === "th" || cell.tagName === "td"))
          .map((cell) => textOf(cell).replace(/\s+/g, " ").trim());
        (inHead ? header : body).push(cells);
      } else {
        visit(child, inHead || child.tagName === "thead");
      }
    }
  };
  visit(table, false);
  return { header, body };
}

/** A column is numeric when every non-empty body cell is a figure. */
export function numericColumns(body: string[][]): boolean[] {
  return columnKinds(body).map((kind) => kind === "figure");
}

/** Text this long wraps; shorter text keeps its column on one line. */
const LONG_TEXT = 32;

/**
 * How each column lays out: figures right-aligned, short text on one line,
 * long text wrapping at a readable width, so a phone scrolls the table instead
 * of crushing every column into a narrow stack.
 */
export function columnKinds(body: string[][]): Array<"figure" | "short" | "long"> {
  const width = Math.max(0, ...body.map((row) => row.length));
  return Array.from({ length: width }, (_, column) => {
    const cells = body.map((row) => row[column] ?? "").filter(Boolean);
    if (cells.length > 0 && cells.every((cell) => NUMERIC_CELL.test(cell))) return "figure";
    return cells.some((cell) => cell.length > LONG_TEXT) ? "long" : "short";
  });
}

function csvCell(value: string): string {
  // A spreadsheet runs a leading = + - @ as a formula unless the cell is a figure.
  const safe = /^[=+\-@\t\r]/.test(value) && !NUMERIC_CELL.test(value) ? `'${value}` : value;
  return /[",\n\r]/.test(safe) || safe !== safe.trim() ? `"${safe.replace(/"/g, '""')}"` : safe;
}

/** RFC 4180 CSV of a rendered Markdown table, header first. */
export function tableCsv(rows: string[][]): string {
  return rows.map((row) => row.map(csvCell).join(",")).join("\n");
}

// Markdown wraps its output in `.tangle-prose`, and a consumer may ship an
// older, unlayered copy of those rules (display: block on tables, cell
// borders, left-aligned headers). Unlayered rules beat layered utilities at
// any specificity, so these scoped overrides are important.
const PROSE_TABLE = "[.tangle-prose_&]:table! [.tangle-prose_&]:m-0! [.tangle-prose_&]:overflow-visible! [.tangle-prose_&]:text-sm!";
const PROSE_CELL = "[.tangle-prose_&]:px-3! [.tangle-prose_&]:py-2! [.tangle-prose_&]:border-t-0! [.tangle-prose_&]:border-l-0!";

const TableColumns = createContext<Array<"figure" | "short" | "long">>([]);
const CellColumn = createContext(-1);

function CopyCsvButton({ csv }: { csv: string }) {
  const [state, setState] = useState<"idle" | "copied" | "failed">("idle");
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => () => { if (timer.current) clearTimeout(timer.current); }, []);
  const copy = useCallback(async () => {
    if (timer.current) clearTimeout(timer.current);
    try {
      await navigator.clipboard.writeText(csv);
      setState("copied");
    } catch {
      setState("failed");
    }
    timer.current = setTimeout(() => setState("idle"), 2000);
  }, [csv]);
  return (
    <>
      <button
        type="button"
        onClick={copy}
        className={cn(
          "inline-flex items-center gap-1.5 rounded-md px-2 py-1 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground",
          focusRing,
        )}
      >
        {state === "copied"
          ? <Check aria-hidden className="size-4 text-[var(--surface-success-text)]" />
          : <Copy aria-hidden className="size-4" />}
        {state === "copied" ? "Copied" : "Copy CSV"}
      </button>
      <span className="sr-only" role="status" aria-live="polite">
        {state === "copied" ? "Table copied as CSV" : state === "failed" ? "Copy failed" : ""}
      </span>
    </>
  );
}

/**
 * A Markdown table as a card: a header row, subtle row lines, figures
 * right-aligned in tabular numerals, a copy-as-CSV control, and horizontal
 * scrolling inside the card when the columns outgrow a phone.
 */
export function MarkdownTable({ node, className, children, ...props }: ComponentProps<"table"> & ExtraProps) {
  const { csv, kinds, rowCount } = useMemo(() => {
    const { header, body } = node ? rowsOf(node) : { header: [], body: [] };
    return { csv: tableCsv([...header, ...body]), kinds: columnKinds(body), rowCount: body.length };
  }, [node]);
  return (
    // `relative` makes the card the containing block of the copy control's
    // screen-reader status line. Without it that absolutely positioned line
    // resolves against the nearest positioned ancestor, often the page, and a
    // table far down a scrolling panel stretches the page past the viewport.
    <div className="not-prose relative my-4 overflow-hidden rounded-lg border border-border bg-card">
      <div className="flex items-center justify-between gap-2 border-b border-border px-3 py-1">
        <span className="text-sm text-muted-foreground">{rowCount === 1 ? "1 row" : `${rowCount} rows`}</span>
        <CopyCsvButton csv={csv} />
      </div>
      {/* A keyboard reaches a sideways-scrolling table only when it can take focus. */}
      <div tabIndex={0} role="region" aria-label="Table" className={cn("overflow-x-auto", focusRingInset)}>
        <TableColumns.Provider value={kinds}>
          <table {...props} data-markdown-table="" className={cn("w-full border-collapse text-sm text-foreground", PROSE_TABLE, className)}>
            {children}
          </table>
        </TableColumns.Provider>
      </div>
    </div>
  );
}

export function MarkdownTableHead({ node: _node, className, ...props }: ComponentProps<"thead"> & ExtraProps) {
  return <thead {...props} className={cn("bg-muted/50", className)} />;
}

export function MarkdownTableBody({ node: _node, className, ...props }: ComponentProps<"tbody"> & ExtraProps) {
  return <tbody {...props} className={cn("[&>tr:last-child>td]:border-b-0", className)} />;
}

export function MarkdownTableRow({ node: _node, children, ...props }: ComponentProps<"tr"> & ExtraProps) {
  let column = 0;
  return (
    <tr {...props}>
      {Children.map(children, (child) =>
        isValidElement(child)
          ? <CellColumn.Provider value={column++}>{child}</CellColumn.Provider>
          : child,
      )}
    </tr>
  );
}

function useColumnKind(): "figure" | "short" | "long" {
  const kinds = useContext(TableColumns);
  const column = useContext(CellColumn);
  return (column >= 0 ? kinds[column] : undefined) ?? "short";
}

export function MarkdownTableHeaderCell({ node: _node, className, ...props }: ComponentProps<"th"> & ExtraProps) {
  const numeric = useColumnKind() === "figure";
  return (
    <th
      {...props}
      className={cn(
        "whitespace-nowrap border-b border-border px-3 py-2 text-left font-semibold text-foreground",
        PROSE_CELL,
        numeric ? "text-right [.tangle-prose_&]:text-right!" : "[.tangle-prose_&]:text-left!",
        className,
      )}
    />
  );
}

export function MarkdownTableCell({ node: _node, className, ...props }: ComponentProps<"td"> & ExtraProps) {
  const kind = useColumnKind();
  return (
    <td
      {...props}
      className={cn(
        "border-b border-border/60 px-3 py-2 align-top",
        PROSE_CELL,
        kind === "figure" ? "whitespace-nowrap text-right tabular-nums"
          : kind === "long" ? "min-w-[14rem]" : "whitespace-nowrap",
        className,
      )}
    />
  );
}
