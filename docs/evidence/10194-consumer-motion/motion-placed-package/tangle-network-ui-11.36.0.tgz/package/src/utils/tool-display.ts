import type { ToolPart } from "../types/parts";
import type { ToolDisplayMetadata } from "../types/tool-display";
import type { ToolCategory } from "../types/run";

// ---------------------------------------------------------------------------
// Tool name normalisation
// ---------------------------------------------------------------------------

const TOOL_NAME_PREFIX = "tool:";

function normalizeToolName(tool: string | undefined): string {
  const n = tool?.toLowerCase() ?? "";
  return n.startsWith(TOOL_NAME_PREFIX) ? n.slice(TOOL_NAME_PREFIX.length) : n;
}

// ---------------------------------------------------------------------------
// Input helpers
// ---------------------------------------------------------------------------

function extractString(obj: unknown, key: string): string | undefined {
  if (
    typeof obj === "object" &&
    obj !== null &&
    key in (obj as Record<string, unknown>)
  ) {
    const val = (obj as Record<string, unknown>)[key];
    if (typeof val === "string") return val;
  }
  return undefined;
}

function extractCommand(input: unknown): string | undefined {
  if (typeof input === "string") return input;
  return extractString(input, "command") ?? extractString(input, "cmd");
}

function extractFilePath(input: unknown): string | undefined {
  return (
    extractString(input, "file_path") ??
    extractString(input, "path") ??
    extractString(input, "filePath") ??
    extractString(input, "file")
  );
}

// ---------------------------------------------------------------------------
// Category icons (emoji shorthand used by compact views)
// ---------------------------------------------------------------------------

export const TOOL_CATEGORY_ICONS: Record<ToolCategory, string> = {
  command: "terminal",
  write: "file-plus",
  read: "file-text",
  search: "search",
  edit: "file-edit",
  task: "cpu",
  web: "globe",
  todo: "check-square",
  other: "box",
};

// ---------------------------------------------------------------------------
// Category classification
// ---------------------------------------------------------------------------

export function getToolCategory(toolName: string): ToolCategory {
  const name = normalizeToolName(toolName);
  switch (name) {
    case "bash":
    case "shell":
    case "command":
    case "execute":
      return "command";
    case "write":
    case "write_file":
    case "create_file":
      return "write";
    case "read":
    case "read_file":
    case "cat":
      return "read";
    case "grep":
    case "search":
    case "rg":
      return "search";
    case "edit":
    case "patch":
    case "sed":
      return "edit";
    case "glob":
    case "find":
    case "ls":
      return "search";
    case "web_search":
    case "web_fetch":
    case "fetch":
      return "web";
    case "task":
    case "agent":
    case "spawn":
      return "task";
    case "todo":
    case "todo_write":
      return "todo";
    default:
      return "other";
  }
}

// ---------------------------------------------------------------------------
// Main metadata resolver
// ---------------------------------------------------------------------------

/**
 * Title is the bare verb ("Read", "Edit", "Shell"); the path, command, pattern
 * or query lives in `description` only, so a row prints its subject once.
 * `targetPath` / `commandSnippet` carry the untruncated value for consumers
 * that need it (diff headers, expanded detail).
 */
export function getToolDisplayMetadata(part: ToolPart): ToolDisplayMetadata {
  const name = normalizeToolName(part.tool);
  const input = part.state.status !== "pending" ? part.state.input : undefined;
  const filePath = extractFilePath(input);
  const command = extractCommand(input);

  switch (name) {
    case "bash":
    case "shell":
    case "command":
    case "execute":
      return {
        title: "Shell",
        description: command ? truncateCommand(command) : undefined,
        displayVariant: "command",
        commandSnippet: command,
      };

    case "write":
    case "write_file":
    case "create_file":
      return {
        title: "Write",
        description: filePath,
        displayVariant: "write-file",
        targetPath: filePath,
      };

    case "edit":
    case "patch":
      return {
        title: "Edit",
        description: filePath,
        hasDiffOutput: true,
        diffFilePath: filePath,
        displayVariant: "diff",
        targetPath: filePath,
      };

    case "read":
    case "read_file":
    case "cat":
      return {
        title: "Read",
        description: filePath,
        displayVariant: "read-file",
        targetPath: filePath,
      };

    case "grep":
    case "search":
    case "rg": {
      const pattern = extractString(input, "pattern");
      return {
        title: "Search",
        description: pattern,
        displayVariant: "grep",
      };
    }

    case "glob":
    case "find":
    case "ls": {
      const pattern = extractString(input, "pattern");
      return {
        title: "Find",
        description: pattern,
        displayVariant: "glob",
      };
    }

    case "web_search":
    case "web_fetch":
    case "fetch": {
      const query =
        extractString(input, "query") ?? extractString(input, "url");
      return {
        title: name === "web_search" ? "Web search" : "Fetch",
        description: query ? truncateCommand(query) : undefined,
        displayVariant: "web-search",
      };
    }

    case "task":
    case "agent":
    case "spawn": {
      const desc =
        extractString(input, "description") ??
        extractString(input, "prompt");
      return {
        title: "Task",
        description: desc ? truncateCommand(desc) : undefined,
      };
    }

    default:
      return {
        title: part.tool || "Tool",
        description:
          command ??
          filePath ??
          extractString(input, "pattern") ??
          extractString(input, "query"),
      };
  }
}

function truncateCommand(cmd: string): string {
  const first = cmd.split("\n")[0];
  return first.length > 60 ? first.slice(0, 57) + "..." : first;
}

/** Extract error text from a tool part, if any. */
export function getToolErrorText(
  part: ToolPart,
  fallback?: string,
): string | undefined {
  if (part.state.status !== "error") return undefined;
  return part.state.error || fallback;
}
